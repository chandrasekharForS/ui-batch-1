document.addEventListener("DOMContentLoaded", function(){
    const addTaskForm = document.getElementById('addTaskForm');
    const taskList = document.getElementById('taskList');

    let tasks = [];

    addTaskForm.addEventListener("submit", function(e){
        e.preventDefault();
        const taskText = document.getElementById('taskText').value;
        tasks.push({text:taskText, completed:false});
        addTaskForm.reset();

        renderTasks();
    });

    function renderTasks() {
        taskList.innerHTML = ''; // Clear existing tasks

        // Loop through tasks array and create list elements
        tasks.forEach((task, index) => {
            const li = document.createElement('li');
            li.className = task.completed ? 'completed' : '';

            const span = document.createElement('span');
            span.textContent = task.text;
            span.addEventListener('click', () => toggleTask(index));
            li.appendChild(span);

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', () => deleteTask(index));
            li.appendChild(deleteButton);

            taskList.appendChild(li);
        });
    }

    function toggleTask(index) {
        tasks[index].completed = !tasks[index].completed;
        renderTasks();
    }

    function deleteTask(index) {
        tasks.splice(index, 1);
        renderTasks();
    }
});
