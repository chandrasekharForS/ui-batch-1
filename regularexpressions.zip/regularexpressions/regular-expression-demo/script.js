const form = document.getElementById("studentForm");


form.addEventListener("submit", function(event) {

    // Prevent form from submitting to server
    event.preventDefault();


    // Get values from input fields

    const name =
        document.getElementById("studentName").value;

    const email =
        document.getElementById("email").value;

    const mobile =
        document.getElementById("mobile").value;

    const password =
        document.getElementById("password").value;

    const pin =
        document.getElementById("pin").value;


    // Regular Expressions

    const nameRegex =
        /^[A-Za-z ]+$/;


    const emailRegex =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


    const mobileRegex =
        /^[6-9][0-9]{9}$/;


    const passwordRegex =
        /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).{8,}$/;


    const pinRegex =
        /^[0-9]{6}$/;


    // Clear previous messages

    document.getElementById("nameError").textContent = "";

    document.getElementById("emailError").textContent = "";

    document.getElementById("mobileError").textContent = "";

    document.getElementById("passwordError").textContent = "";

    document.getElementById("pinError").textContent = "";

    document.getElementById("successMessage").textContent = "";


    let valid = true;


    // Validate Student Name

    if (!nameRegex.test(name)) {

        document.getElementById("nameError").textContent =
            "Name should contain only letters and spaces.";

        valid = false;
    }


    // Validate Email

    if (!emailRegex.test(email)) {

        document.getElementById("emailError").textContent =
            "Enter a valid email address.";

        valid = false;
    }


    // Validate Mobile

    if (!mobileRegex.test(mobile)) {

        document.getElementById("mobileError").textContent =
            "Enter a valid 10 digit Indian mobile number.";

        valid = false;
    }


    // Validate Password

    if (!passwordRegex.test(password)) {

        document.getElementById("passwordError").textContent =
            "Password must contain uppercase, lowercase, number and minimum 8 characters.";

        valid = false;
    }


    // Validate PIN

    if (!pinRegex.test(pin)) {

        document.getElementById("pinError").textContent =
            "PIN must contain exactly 6 digits.";

        valid = false;
    }


    // Display final result

    if (valid) {

        document.getElementById("successMessage").textContent =
            "Student registration successful!";

    }

});
