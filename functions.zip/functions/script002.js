
document.addEventListener('DOMContentLoaded', function() {
    const productForm = document.getElementById('productForm');
    const productList = document.getElementById('productList');
    const filterInput = document.getElementById('filterInput');
    const updateButton = document.getElementById('updateButton');
    const submitButton = document.querySelector('button[type="submit"]');

    let products = [];
    let editIndex = null;

    productForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const productName = document.getElementById('productName').value;
        const productPrice = parseFloat(document.getElementById('productPrice').value);

        if (editIndex === null) {
            addProduct(productName, productPrice);
        } else {
            updateProduct(editIndex, productName, productPrice);
        }

        productForm.reset(); // clear the form
        renderProducts();
    });

    updateButton.addEventListener('click', function() {
        const productName = document.getElementById('productName').value;
        const productPrice = parseFloat(document.getElementById('productPrice').value);
        
        updateProduct(editIndex, productName, productPrice);
        productForm.reset(); // clear the form
        renderProducts();
    });

    filterInput.addEventListener('input', function() {
        renderProducts();
    });

    function addProduct(name, price) {
        const newProduct = { name, price };
        products.push(newProduct);
    }

    function updateProduct(index, name, price) {
        products[index] = { name, price };
        editIndex = null;
        submitButton.style.display = 'block';
        updateButton.style.display = 'none';
    }

    function renderProducts() {
        const filterText = filterInput.value.toLowerCase();
        productList.innerHTML = '';

        products.forEach((product, index) => {
            if (product.name.toLowerCase().includes(filterText)) {
                const li = document.createElement('li');
                li.textContent = `${product.name}: $${product.price.toFixed(2)}`;

                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.className = 'edit';
                editButton.onclick = () => {
                    editIndex = index;
                    document.getElementById('productName').value = product.name;
                    document.getElementById('productPrice').value = product.price;
                    submitButton.style.display = 'none';
                    updateButton.style.display = 'block';
                };

                const removeButton = document.createElement('button');
                removeButton.textContent = 'Remove';
                removeButton.className = 'remove';
                removeButton.onclick = () => {
                    removeProduct(index);
                };

                li.appendChild(editButton);
                li.appendChild(removeButton);

                productList.appendChild(li);
            }
        });
    }

    function removeProduct(index) {
        products.splice(index, 1);
        renderProducts();
    }
});

/*document.addEventListener('DOMContentLoaded', function() {
    const productForm = document.getElementById('productForm');
    const productList = document.getElementById('productList');
    const filterInput = document.getElementById('filterInput');
    const updateButton = document.getElementById('updateButton');
    const submitButton = document.querySelector('button[type="submit"]');

    let products = [];
    let editIndex = null;


    productForm.addEventListener("submit", function(e){
        e.preventDefault();

        let name = document.getElementById("productName").value;
        let price = parseFloat(document.getElementById("productPrice").value);


        if(editIndex === null) {
            addProduct(name, price);
        }
        else{
            updateProduct(editIndex, name, price);
        }
        
        productForm.reset();
        
        rendorProducts();
    });

       

    updateButton.addEventListener("click", function(){
        
        
        const productName = document.getElementById("productName").value;
        const productPrice = document.getElementById("productPrice").value;
        
        updateProduct(editIndex, productName, productPrice);
        
        productForm.reset();
        rendorProducts();
    });

    function updateProduct(index, name, price) {
        products[index] = {name, price};

        editIndex = null;

        submitButton.style.display = "block";
        updateButton.style.display = "none";

        alert(products.length);

    }

    function addProduct(name, price) {
        let product = {name, price};
        products.push(product);

    }

    function removeProduct(index){
        products.splice(index, 1);
        rendorProducts();
    }

    function rendorProducts() {
        //alert("Update button is clicked.");
        const filterText = filterInput.value.toLowerCase();
        productList.innerHTML = "";

    
        products.forEach((product, index) => {
            if(product.name.toLowerCase().includes(filterText)) {
                const li = document.createElement("li");
                li.textContent = `${product.name}: $${product.price.toFixed(2)}`;

                const editButton = document.createElement("button");
                editButton.textContent = "Edit";
                editButton.className = "edit";

                editButton.onclick = () => {
                    editIndex = index;
                    document.getElementById("productName").value = product.name;
                    document.getElementById("productPrice").value = product.price;

                    submitButton.style.display = "none";
                    updateButton.style.display = "block";
                };



                const removeButton = document.createElement("button");
                removeButton.textContent = "Delete";
                removeButton.className="remove";

                removeButton.onclick = () => {
                    removeProduct(index);
                };



                li.appendChild(editButton);
                li.appendChild(removeButton);

                productList.appendChild(li);
            }
        });
    }

});
*/
